import { Router, type IRouter } from "express";
import healthRouter from "./health";
import postsRouter from "./posts";
import categoriesRouter from "./categories";
import tagsRouter from "./tags";
import authorsRouter from "./authors";
import statsRouter from "./stats";

const router: IRouter = Router();

router.use(healthRouter);
router.use(postsRouter);
router.use(categoriesRouter);
router.use(tagsRouter);
router.use(authorsRouter);
router.use(statsRouter);

export default router;
