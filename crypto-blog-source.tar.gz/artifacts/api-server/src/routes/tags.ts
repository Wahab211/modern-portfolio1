import { Router } from "express";
import { db } from "@workspace/db";
import { tagsTable, postTagsTable } from "@workspace/db";
import { sql } from "drizzle-orm";

const router = Router();

function slugify(text: string): string {
  return text.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}

router.get("/tags", async (req, res) => {
  try {
    const tags = await db.select().from(tagsTable).orderBy(tagsTable.name);
    const postCounts = await db
      .select({ tagId: postTagsTable.tagId, count: sql<number>`count(*)`.mapWith(Number) })
      .from(postTagsTable)
      .groupBy(postTagsTable.tagId);
    const countMap = Object.fromEntries(postCounts.map((r) => [r.tagId, r.count]));
    const result = tags.map((t) => ({ ...t, postCount: countMap[t.id] ?? 0 }));
    res.json(result);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/tags", async (req, res) => {
  try {
    const { name } = req.body;
    if (!name) return void res.status(400).json({ error: "Name is required" });
    const slug = slugify(name);
    const [tag] = await db.insert(tagsTable).values({ name, slug }).returning();
    res.status(201).json({ ...tag, postCount: 0 });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
