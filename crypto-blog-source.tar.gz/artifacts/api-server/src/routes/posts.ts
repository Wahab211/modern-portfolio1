import { Router } from "express";
import { db } from "@workspace/db";
import { postsTable, categoriesTable, authorsTable, tagsTable, postTagsTable } from "@workspace/db";
import { eq, ilike, and, sql, inArray } from "drizzle-orm";

const router = Router();

function slugify(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
}

function estimateReadingTime(content: string): number {
  const words = content.split(/\s+/).length;
  return Math.max(1, Math.ceil(words / 200));
}

async function enrichPosts(posts: (typeof postsTable.$inferSelect)[]) {
  if (posts.length === 0) return [];

  const categoryIds = [...new Set(posts.map((p) => p.categoryId))];
  const authorIds = [...new Set(posts.map((p) => p.authorId))];
  const postIds = posts.map((p) => p.id);

  const [categories, authors, postTagRows, allTags] = await Promise.all([
    db.select().from(categoriesTable).where(inArray(categoriesTable.id, categoryIds)),
    db.select().from(authorsTable).where(inArray(authorsTable.id, authorIds)),
    db.select().from(postTagsTable).where(inArray(postTagsTable.postId, postIds)),
    db.select().from(tagsTable),
  ]);

  const catMap = Object.fromEntries(categories.map((c) => [c.id, c]));
  const authorMap = Object.fromEntries(authors.map((a) => [a.id, a]));
  const tagMap = Object.fromEntries(allTags.map((t) => [t.id, t]));

  const postTagMap: Record<number, (typeof tagsTable.$inferSelect)[]> = {};
  for (const pt of postTagRows) {
    if (!postTagMap[pt.postId]) postTagMap[pt.postId] = [];
    if (tagMap[pt.tagId]) postTagMap[pt.postId].push(tagMap[pt.tagId]);
  }

  return posts.map((p) => ({
    ...p,
    category: catMap[p.categoryId] ?? null,
    author: authorMap[p.authorId] ?? null,
    tags: postTagMap[p.id] ?? [],
    createdAt: p.createdAt.toISOString(),
    updatedAt: p.updatedAt.toISOString(),
  }));
}

router.get("/posts", async (req, res) => {
  try {
    const { category, tag, featured, search, limit = "20", offset = "0" } = req.query as Record<string, string>;

    const conditions = [];

    if (category) {
      const cat = await db.select().from(categoriesTable).where(eq(categoriesTable.slug, category)).limit(1);
      if (cat.length > 0) conditions.push(eq(postsTable.categoryId, cat[0].id));
    }

    if (featured === "true") {
      conditions.push(eq(postsTable.featured, true));
    }

    if (search) {
      conditions.push(ilike(postsTable.title, `%${search}%`));
    }

    let posts = await db
      .select()
      .from(postsTable)
      .where(conditions.length ? and(...conditions) : undefined)
      .limit(parseInt(limit))
      .offset(parseInt(offset))
      .orderBy(sql`${postsTable.createdAt} desc`);

    if (tag) {
      const tagRow = await db.select().from(tagsTable).where(eq(tagsTable.slug, tag)).limit(1);
      if (tagRow.length > 0) {
        const taggedPostIds = await db
          .select({ postId: postTagsTable.postId })
          .from(postTagsTable)
          .where(eq(postTagsTable.tagId, tagRow[0].id));
        const ids = taggedPostIds.map((r) => r.postId);
        posts = posts.filter((p) => ids.includes(p.id));
      }
    }

    const enriched = await enrichPosts(posts);
    res.json(enriched);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/posts/featured", async (req, res) => {
  try {
    const posts = await db
      .select()
      .from(postsTable)
      .where(and(eq(postsTable.featured, true), eq(postsTable.status, "published")))
      .limit(5)
      .orderBy(sql`${postsTable.createdAt} desc`);
    const enriched = await enrichPosts(posts);
    res.json(enriched);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/posts/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [post] = await db.select().from(postsTable).where(eq(postsTable.id, id)).limit(1);
    if (!post) return void res.status(404).json({ error: "Not found" });

    await db.update(postsTable).set({ views: post.views + 1 }).where(eq(postsTable.id, id));

    const enriched = await enrichPosts([{ ...post, views: post.views + 1 }]);
    res.json(enriched[0]);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/posts", async (req, res) => {
  try {
    const { title, content, excerpt, coverImage, status = "draft", featured = false, categoryId, authorId, tags = [] } = req.body;

    if (!title || !content || !excerpt || !categoryId || !authorId) {
      return void res.status(400).json({ error: "Missing required fields" });
    }

    const slug = slugify(title) + "-" + Date.now();
    const readingTime = estimateReadingTime(content);

    const [post] = await db.insert(postsTable).values({
      title,
      slug,
      content,
      excerpt,
      coverImage: coverImage || null,
      status,
      featured: Boolean(featured),
      readingTime,
      categoryId: parseInt(String(categoryId)),
      authorId: parseInt(String(authorId)),
    }).returning();

    if (Array.isArray(tags) && tags.length > 0) {
      for (const tagName of tags) {
        const tagSlug = slugify(String(tagName));
        let [tag] = await db.select().from(tagsTable).where(eq(tagsTable.slug, tagSlug)).limit(1);
        if (!tag) {
          [tag] = await db.insert(tagsTable).values({ name: String(tagName), slug: tagSlug }).returning();
        }
        await db.insert(postTagsTable).values({ postId: post.id, tagId: tag.id }).onConflictDoNothing();
      }
    }

    const enriched = await enrichPosts([post]);
    res.status(201).json(enriched[0]);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/posts/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { title, content, excerpt, coverImage, status, featured, categoryId, authorId, tags } = req.body;

    const setValues: Partial<typeof postsTable.$inferInsert & { updatedAt: Date }> = {
      updatedAt: new Date(),
    };

    if (title !== undefined) {
      setValues.title = title;
      setValues.slug = slugify(title) + "-" + id;
    }
    if (content !== undefined) {
      setValues.content = content;
      setValues.readingTime = estimateReadingTime(content);
    }
    if (excerpt !== undefined) setValues.excerpt = excerpt;
    if (coverImage !== undefined) setValues.coverImage = coverImage;
    if (status !== undefined) setValues.status = status;
    if (featured !== undefined) setValues.featured = Boolean(featured);
    if (categoryId !== undefined) setValues.categoryId = parseInt(String(categoryId));
    if (authorId !== undefined) setValues.authorId = parseInt(String(authorId));

    const [post] = await db.update(postsTable).set(setValues).where(eq(postsTable.id, id)).returning();
    if (!post) return void res.status(404).json({ error: "Not found" });

    if (Array.isArray(tags)) {
      await db.delete(postTagsTable).where(eq(postTagsTable.postId, id));
      for (const tagName of tags) {
        const tagSlug = slugify(String(tagName));
        let [tag] = await db.select().from(tagsTable).where(eq(tagsTable.slug, tagSlug)).limit(1);
        if (!tag) {
          [tag] = await db.insert(tagsTable).values({ name: String(tagName), slug: tagSlug }).returning();
        }
        await db.insert(postTagsTable).values({ postId: post.id, tagId: tag.id }).onConflictDoNothing();
      }
    }

    const enriched = await enrichPosts([post]);
    res.json(enriched[0]);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.delete("/posts/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    await db.delete(postTagsTable).where(eq(postTagsTable.postId, id));
    await db.delete(postsTable).where(eq(postsTable.id, id));
    res.status(204).send();
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
