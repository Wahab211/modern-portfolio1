import { Router } from "express";
import { db } from "@workspace/db";
import { authorsTable, postsTable } from "@workspace/db";
import { eq, sql } from "drizzle-orm";

const router = Router();

router.get("/authors", async (req, res) => {
  try {
    const authors = await db.select().from(authorsTable).orderBy(authorsTable.name);
    const postCounts = await db
      .select({ authorId: postsTable.authorId, count: sql<number>`count(*)`.mapWith(Number) })
      .from(postsTable)
      .groupBy(postsTable.authorId);
    const countMap = Object.fromEntries(postCounts.map((r) => [r.authorId, r.count]));
    const result = authors.map((a) => ({
      ...a,
      postCount: countMap[a.id] ?? 0,
      createdAt: a.createdAt.toISOString(),
      updatedAt: a.updatedAt.toISOString(),
    }));
    res.json(result);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/authors", async (req, res) => {
  try {
    const { name, email, bio, avatar, twitter } = req.body;
    if (!name || !email) return void res.status(400).json({ error: "Name and email are required" });

    const [author] = await db
      .insert(authorsTable)
      .values({ name, email, bio: bio || null, avatar: avatar || null, twitter: twitter || null })
      .returning();
    res.status(201).json({
      ...author,
      postCount: 0,
      createdAt: author.createdAt.toISOString(),
      updatedAt: author.updatedAt.toISOString(),
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/authors/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [author] = await db.select().from(authorsTable).where(eq(authorsTable.id, id)).limit(1);
    if (!author) return void res.status(404).json({ error: "Not found" });

    const [countRow] = await db
      .select({ count: sql<number>`count(*)`.mapWith(Number) })
      .from(postsTable)
      .where(eq(postsTable.authorId, id));

    res.json({
      ...author,
      postCount: countRow?.count ?? 0,
      createdAt: author.createdAt.toISOString(),
      updatedAt: author.updatedAt.toISOString(),
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/authors/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { name, email, bio, avatar, twitter } = req.body;

    const setValues: Partial<typeof authorsTable.$inferInsert & { updatedAt: Date }> = {
      updatedAt: new Date(),
    };
    if (name !== undefined) setValues.name = name;
    if (email !== undefined) setValues.email = email;
    if (bio !== undefined) setValues.bio = bio;
    if (avatar !== undefined) setValues.avatar = avatar;
    if (twitter !== undefined) setValues.twitter = twitter;

    const [author] = await db.update(authorsTable).set(setValues).where(eq(authorsTable.id, id)).returning();
    if (!author) return void res.status(404).json({ error: "Not found" });
    res.json({
      ...author,
      postCount: 0,
      createdAt: author.createdAt.toISOString(),
      updatedAt: author.updatedAt.toISOString(),
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
