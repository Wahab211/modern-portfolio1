import { Router } from "express";
import { db } from "@workspace/db";
import { categoriesTable, postsTable } from "@workspace/db";
import { eq, sql } from "drizzle-orm";

const router = Router();

function slugify(text: string): string {
  return text.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}

router.get("/categories", async (req, res) => {
  try {
    const categories = await db.select().from(categoriesTable).orderBy(categoriesTable.name);
    const postCounts = await db
      .select({ categoryId: postsTable.categoryId, count: sql<number>`count(*)`.mapWith(Number) })
      .from(postsTable)
      .groupBy(postsTable.categoryId);
    const countMap = Object.fromEntries(postCounts.map((r) => [r.categoryId, r.count]));
    const result = categories.map((c) => ({ ...c, postCount: countMap[c.id] ?? 0 }));
    res.json(result);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/categories", async (req, res) => {
  try {
    const { name, description, color = "#6366f1" } = req.body;
    if (!name) return void res.status(400).json({ error: "Name is required" });

    const slug = slugify(name);
    const [cat] = await db
      .insert(categoriesTable)
      .values({ name, slug, description: description || null, color })
      .returning();
    res.status(201).json({ ...cat, postCount: 0 });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/categories/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { name, description, color } = req.body;

    const setValues: Partial<typeof categoriesTable.$inferInsert & { updatedAt: Date }> = {
      updatedAt: new Date(),
    };
    if (name !== undefined) { setValues.name = name; setValues.slug = slugify(name); }
    if (description !== undefined) setValues.description = description;
    if (color !== undefined) setValues.color = color;

    const [cat] = await db.update(categoriesTable).set(setValues).where(eq(categoriesTable.id, id)).returning();
    if (!cat) return void res.status(404).json({ error: "Not found" });
    res.json({ ...cat, postCount: 0 });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.delete("/categories/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    await db.delete(categoriesTable).where(eq(categoriesTable.id, id));
    res.status(204).send();
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
