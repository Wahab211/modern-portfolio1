import { Router } from "express";
import { db } from "@workspace/db";
import { postsTable, categoriesTable, authorsTable, tagsTable, postTagsTable } from "@workspace/db";
import { eq, sql, inArray } from "drizzle-orm";

const router = Router();

async function enrichPosts(posts: typeof postsTable.$inferSelect[]) {
  if (posts.length === 0) return [];
  const categoryIds = [...new Set(posts.map((p) => p.categoryId))];
  const authorIds = [...new Set(posts.map((p) => p.authorId))];
  const postIds = posts.map((p) => p.id);

  const [categories, authors, postTagRows, allTags] = await Promise.all([
    db.select().from(categoriesTable).where(inArray(categoriesTable.id, categoryIds)),
    db.select().from(authorsTable).where(inArray(authorsTable.id, authorIds)),
    db.select().from(postTagsTable).where(inArray(postTagsTable.postId, postIds)),
    db.select().from(tagsTable),
  ]);

  const catMap = Object.fromEntries(categories.map((c) => [c.id, c]));
  const authorMap = Object.fromEntries(authors.map((a) => [a.id, a]));
  const tagMap = Object.fromEntries(allTags.map((t) => [t.id, t]));
  const postTagMap: Record<number, typeof tagsTable.$inferSelect[]> = {};
  for (const pt of postTagRows) {
    if (!postTagMap[pt.postId]) postTagMap[pt.postId] = [];
    if (tagMap[pt.tagId]) postTagMap[pt.postId].push(tagMap[pt.tagId]);
  }

  return posts.map((p) => ({
    ...p,
    category: catMap[p.categoryId] ?? null,
    author: authorMap[p.authorId] ?? null,
    tags: postTagMap[p.id] ?? [],
    createdAt: p.createdAt.toISOString(),
    updatedAt: p.updatedAt.toISOString(),
  }));
}

router.get("/stats", async (req, res) => {
  try {
    const [
      [totalRow],
      [publishedRow],
      [draftRow],
      [catCountRow],
      [authorCountRow],
      [viewsRow],
      recentPosts,
    ] = await Promise.all([
      db.select({ count: sql<number>`count(*)`.mapWith(Number) }).from(postsTable),
      db.select({ count: sql<number>`count(*)`.mapWith(Number) }).from(postsTable).where(eq(postsTable.status, "published")),
      db.select({ count: sql<number>`count(*)`.mapWith(Number) }).from(postsTable).where(eq(postsTable.status, "draft")),
      db.select({ count: sql<number>`count(*)`.mapWith(Number) }).from(categoriesTable),
      db.select({ count: sql<number>`count(*)`.mapWith(Number) }).from(authorsTable),
      db.select({ total: sql<number>`sum(views)`.mapWith(Number) }).from(postsTable),
      db.select().from(postsTable).orderBy(sql`${postsTable.createdAt} desc`).limit(5),
    ]);

    const enrichedRecent = await enrichPosts(recentPosts);

    res.json({
      totalPosts: totalRow?.count ?? 0,
      publishedPosts: publishedRow?.count ?? 0,
      draftPosts: draftRow?.count ?? 0,
      totalCategories: catCountRow?.count ?? 0,
      totalAuthors: authorCountRow?.count ?? 0,
      totalViews: viewsRow?.total ?? 0,
      recentPosts: enrichedRecent,
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
