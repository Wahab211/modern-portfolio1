import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/theme-provider";
import NotFound from "@/pages/not-found";

import Home from "@/pages/public/Home";
import BlogList from "@/pages/public/BlogList";
import PostDetail from "@/pages/public/PostDetail";
import Dashboard from "@/pages/admin/Dashboard";
import PostList from "@/pages/admin/PostList";
import PostForm from "@/pages/admin/PostForm";
import CategoryList from "@/pages/admin/CategoryList";
import TagList from "@/pages/admin/TagList";
import AuthorList from "@/pages/admin/AuthorList";

const queryClient = new QueryClient();

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/blog" component={BlogList} />
      <Route path="/blog/:id" component={PostDetail} />
      
      <Route path="/admin" component={Dashboard} />
      <Route path="/admin/posts" component={PostList} />
      <Route path="/admin/posts/new" component={PostForm} />
      <Route path="/admin/posts/:id/edit" component={PostForm} />
      <Route path="/admin/categories" component={CategoryList} />
      <Route path="/admin/tags" component={TagList} />
      <Route path="/admin/authors" component={AuthorList} />
      
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ThemeProvider defaultTheme="dark">
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            <Router />
          </WouterRouter>
          <Toaster />
        </TooltipProvider>
      </QueryClientProvider>
    </ThemeProvider>
  );
}

export default App;
