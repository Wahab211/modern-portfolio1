import { AdminLayout } from "@/components/layout/AdminLayout";
import { useListPosts, useDeletePost, getListPostsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Plus, Edit, Trash2, Loader2, TrendingUp } from "lucide-react";
import { format } from "date-fns";
import { Link } from "wouter";
import { useToast } from "@/hooks/use-toast";

export default function PostList() {
  const { data: posts, isLoading } = useListPosts();
  const deletePost = useDeletePost();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const handleDelete = async (id: number) => {
    if (confirm("Are you sure you want to delete this post?")) {
      deletePost.mutate({ id }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListPostsQueryKey() });
          toast({ title: "TX_CONFIRMED", description: "Post deleted permanently." });
        },
        onError: () => {
          toast({ title: "TX_FAILED", description: "Failed to delete post.", variant: "destructive" });
        }
      });
    }
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-mono font-bold tracking-tight uppercase">Posts Ledger</h1>
          <Button asChild className="rounded-none font-mono">
            <Link href="/admin/posts/new">
              <Plus className="mr-2 h-4 w-4" /> NEW_BLOCK
            </Link>
          </Button>
        </div>

        {isLoading ? (
          <div className="flex h-32 items-center justify-center">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : (
          <div className="border border-border bg-card">
            <Table>
              <TableHeader>
                <TableRow className="border-border hover:bg-transparent">
                  <TableHead className="font-mono">Title</TableHead>
                  <TableHead className="font-mono">Category</TableHead>
                  <TableHead className="font-mono">Status</TableHead>
                  <TableHead className="font-mono">Date</TableHead>
                  <TableHead className="font-mono text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {posts?.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center font-mono text-muted-foreground py-8">
                      LEDGER_EMPTY
                    </TableCell>
                  </TableRow>
                ) : (
                  posts?.map((post) => (
                    <TableRow key={post.id} className="border-border">
                      <TableCell className="font-medium">
                        <div className="flex items-center gap-2">
                          <span className="font-mono">{post.title}</span>
                          {post.featured && <TrendingUp className="h-3 w-3 text-primary" />}
                        </div>
                      </TableCell>
                      <TableCell className="font-mono text-muted-foreground">
                        {post.category?.name || "None"}
                      </TableCell>
                      <TableCell>
                        <Badge variant={post.status === "published" ? "default" : "secondary"} className="rounded-none font-mono uppercase text-xs">
                          {post.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="font-mono text-muted-foreground text-sm">
                        {format(new Date(post.createdAt), "MMM d, yyyy")}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button asChild variant="ghost" size="icon" className="rounded-none hover:text-primary">
                            <Link href={`/admin/posts/${post.id}/edit`}>
                              <Edit className="h-4 w-4" />
                            </Link>
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="rounded-none text-destructive hover:bg-destructive hover:text-destructive-foreground"
                            onClick={() => handleDelete(post.id)}
                            disabled={deletePost.isPending}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        )}
      </div>
    </AdminLayout>
  );
}
