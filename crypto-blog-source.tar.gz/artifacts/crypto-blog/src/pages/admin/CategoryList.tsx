import { AdminLayout } from "@/components/layout/AdminLayout";
import { useListCategories, useDeleteCategory, getListCategoriesQueryKey, useCreateCategory, useUpdateCategory, Category } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Trash2, Loader2, Plus, Edit } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useState } from "react";

const formSchema = z.object({
  name: z.string().min(1, "Name is required"),
  description: z.string().optional(),
  color: z.string().min(1, "Color is required"),
});

export default function CategoryList() {
  const { data: categories, isLoading } = useListCategories();
  const deleteCategory = useDeleteCategory();
  const createCategory = useCreateCategory();
  const updateCategory = useUpdateCategory();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const [open, setOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: { name: "", description: "", color: "#00FF7F" },
  });

  const handleOpenNew = () => {
    setEditingCategory(null);
    form.reset({ name: "", description: "", color: "#00FF7F" });
    setOpen(true);
  };

  const handleOpenEdit = (category: Category) => {
    setEditingCategory(category);
    form.reset({
      name: category.name,
      description: category.description || "",
      color: category.color
    });
    setOpen(true);
  };

  const handleDelete = async (id: number) => {
    if (confirm("Are you sure?")) {
      deleteCategory.mutate({ id }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListCategoriesQueryKey() });
          toast({ title: "TX_CONFIRMED", description: "Category deleted." });
        },
        onError: () => toast({ title: "TX_FAILED", variant: "destructive" })
      });
    }
  };

  const onSubmit = (values: z.infer<typeof formSchema>) => {
    if (editingCategory) {
      updateCategory.mutate({ id: editingCategory.id, data: values }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListCategoriesQueryKey() });
          toast({ title: "TX_CONFIRMED", description: "Category updated." });
          setOpen(false);
        },
        onError: () => toast({ title: "TX_FAILED", variant: "destructive" })
      });
    } else {
      createCategory.mutate({ data: values }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListCategoriesQueryKey() });
          toast({ title: "TX_CONFIRMED", description: "Category created." });
          setOpen(false);
        },
        onError: () => toast({ title: "TX_FAILED", variant: "destructive" })
      });
    }
  };

  const isPending = createCategory.isPending || updateCategory.isPending;

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-mono font-bold tracking-tight uppercase">Categories</h1>
          <Dialog open={open} onOpenChange={setOpen}>
            <Button onClick={handleOpenNew} className="rounded-none font-mono">
              <Plus className="mr-2 h-4 w-4" /> ADD_TAG
            </Button>
            <DialogContent className="rounded-none border-border bg-card">
              <DialogHeader>
                <DialogTitle className="font-mono uppercase">{editingCategory ? "Update Category" : "New Category"}</DialogTitle>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="font-mono">Name</FormLabel>
                        <FormControl><Input {...field} className="rounded-none font-mono" /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="font-mono">Description</FormLabel>
                        <FormControl><Input {...field} className="rounded-none font-mono" /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="color"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="font-mono">Color Hex</FormLabel>
                        <FormControl><Input {...field} type="color" className="rounded-none h-10 w-full cursor-pointer" /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <Button type="submit" disabled={isPending} className="w-full rounded-none font-mono">
                    {isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />} SUBMIT_TX
                  </Button>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>

        {isLoading ? (
          <div className="flex h-32 items-center justify-center">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : (
          <div className="border border-border bg-card">
            <Table>
              <TableHeader>
                <TableRow className="border-border hover:bg-transparent">
                  <TableHead className="font-mono">Color</TableHead>
                  <TableHead className="font-mono">Name</TableHead>
                  <TableHead className="font-mono">Description</TableHead>
                  <TableHead className="font-mono text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {categories?.map((cat) => (
                  <TableRow key={cat.id} className="border-border">
                    <TableCell>
                      <div className="h-6 w-6 rounded-none border border-border" style={{ backgroundColor: cat.color }} />
                    </TableCell>
                    <TableCell className="font-medium font-mono">{cat.name}</TableCell>
                    <TableCell className="font-mono text-muted-foreground">{cat.description}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="rounded-none hover:text-primary"
                          onClick={() => handleOpenEdit(cat)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="rounded-none text-destructive hover:bg-destructive hover:text-destructive-foreground"
                          onClick={() => handleDelete(cat.id)}
                          disabled={deleteCategory.isPending}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </div>
    </AdminLayout>
  );
}
