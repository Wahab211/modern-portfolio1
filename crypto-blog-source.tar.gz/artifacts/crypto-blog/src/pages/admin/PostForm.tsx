import { AdminLayout } from "@/components/layout/AdminLayout";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { 
  useGetPost, 
  useCreatePost, 
  useUpdatePost, 
  useListCategories, 
  useListAuthors,
  getGetPostQueryKey
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useParams, useLocation } from "wouter";
import { useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { Loader2, ArrowLeft } from "lucide-react";
import { Link } from "wouter";

const formSchema = z.object({
  title: z.string().min(1, "Title is required"),
  content: z.string().min(1, "Content is required"),
  excerpt: z.string(),
  coverImage: z.string().optional(),
  status: z.enum(["draft", "published"]),
  featured: z.boolean().default(false),
  categoryId: z.coerce.number().min(1, "Category is required"),
  authorId: z.coerce.number().min(1, "Author is required"),
});

type FormValues = z.infer<typeof formSchema>;

export default function PostForm() {
  const { id } = useParams();
  const isEditing = Boolean(id);
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: post, isLoading: isLoadingPost } = useGetPost(Number(id), { 
    query: { enabled: isEditing, queryKey: getGetPostQueryKey(Number(id)) } 
  });
  const { data: categories } = useListCategories();
  const { data: authors } = useListAuthors();

  const createPost = useCreatePost();
  const updatePost = useUpdatePost();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      content: "",
      excerpt: "",
      coverImage: "",
      status: "draft",
      featured: false,
      categoryId: 0,
      authorId: 0,
    },
  });

  const initializedRef = useRef(false);

  useEffect(() => {
    if (isEditing && post && !initializedRef.current) {
      form.reset({
        title: post.title,
        content: post.content,
        excerpt: post.excerpt,
        coverImage: post.coverImage || "",
        status: post.status,
        featured: post.featured || false,
        categoryId: post.categoryId,
        authorId: post.authorId,
      });
      initializedRef.current = true;
    }
  }, [post, isEditing, form]);

  const onSubmit = (values: FormValues) => {
    if (isEditing) {
      updatePost.mutate({ id: Number(id), data: values }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetPostQueryKey(Number(id)) });
          toast({ title: "TX_CONFIRMED", description: "Post updated successfully." });
          setLocation("/admin/posts");
        },
        onError: () => {
          toast({ title: "TX_FAILED", description: "Failed to update post.", variant: "destructive" });
        }
      });
    } else {
      createPost.mutate({ data: values }, {
        onSuccess: () => {
          toast({ title: "TX_CONFIRMED", description: "Post created successfully." });
          setLocation("/admin/posts");
        },
        onError: () => {
          toast({ title: "TX_FAILED", description: "Failed to create post.", variant: "destructive" });
        }
      });
    }
  };

  if (isEditing && isLoadingPost) {
    return (
      <AdminLayout>
        <div className="flex h-32 items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </AdminLayout>
    );
  }

  const isPending = createPost.isPending || updatePost.isPending;

  return (
    <AdminLayout>
      <div className="max-w-4xl space-y-6 pb-16">
        <div className="flex items-center gap-4">
          <Button asChild variant="ghost" size="icon" className="rounded-none">
            <Link href="/admin/posts"><ArrowLeft className="h-4 w-4" /></Link>
          </Button>
          <h1 className="text-3xl font-mono font-bold tracking-tight uppercase">
            {isEditing ? "EDIT_BLOCK" : "NEW_BLOCK"}
          </h1>
        </div>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
            <div className="grid gap-6 md:grid-cols-2">
              <div className="md:col-span-2">
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="font-mono uppercase">Title</FormLabel>
                      <FormControl>
                        <Input {...field} className="font-mono rounded-none" placeholder="Enter block title..." />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="md:col-span-2">
                <FormField
                  control={form.control}
                  name="excerpt"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="font-mono uppercase">Excerpt</FormLabel>
                      <FormControl>
                        <Textarea {...field} className="font-mono rounded-none min-h-[80px]" placeholder="Brief summary..." />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="md:col-span-2">
                <FormField
                  control={form.control}
                  name="content"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="font-mono uppercase">Content</FormLabel>
                      <FormControl>
                        <Textarea {...field} className="font-mono rounded-none min-h-[400px]" placeholder="Write content here..." />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="categoryId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="font-mono uppercase">Category</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value ? field.value.toString() : ""}>
                      <FormControl>
                        <SelectTrigger className="font-mono rounded-none">
                          <SelectValue placeholder="Select a category" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent className="rounded-none font-mono">
                        {categories?.map((cat) => (
                          <SelectItem key={cat.id} value={cat.id.toString()}>{cat.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="authorId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="font-mono uppercase">Author</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value ? field.value.toString() : ""}>
                      <FormControl>
                        <SelectTrigger className="font-mono rounded-none">
                          <SelectValue placeholder="Select an author" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent className="rounded-none font-mono">
                        {authors?.map((author) => (
                          <SelectItem key={author.id} value={author.id.toString()}>{author.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="coverImage"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="font-mono uppercase">Cover Image URL</FormLabel>
                    <FormControl>
                      <Input {...field} className="font-mono rounded-none" placeholder="https://..." />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="status"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="font-mono uppercase">Status</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger className="font-mono rounded-none">
                          <SelectValue />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent className="rounded-none font-mono">
                        <SelectItem value="draft">DRAFT</SelectItem>
                        <SelectItem value="published">PUBLISHED</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex items-center gap-8 md:col-span-2 pt-4">
                <FormField
                  control={form.control}
                  name="featured"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center gap-3 space-y-0">
                      <FormControl>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                          className="data-[state=checked]:bg-primary"
                        />
                      </FormControl>
                      <FormLabel className="font-mono uppercase">Featured Post</FormLabel>
                    </FormItem>
                  )}
                />
              </div>
            </div>

            <Button type="submit" disabled={isPending} className="font-mono rounded-none w-full md:w-auto min-w-[200px]">
              {isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {isEditing ? "UPDATE_BLOCK" : "MINING_BLOCK..."}
            </Button>
          </form>
        </Form>
      </div>
    </AdminLayout>
  );
}
