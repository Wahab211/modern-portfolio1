import { AdminLayout } from "@/components/layout/AdminLayout";
import { useListAuthors, getListAuthorsQueryKey, useCreateAuthor, useUpdateAuthor, Author } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Loader2, Plus, Edit } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useState } from "react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

const formSchema = z.object({
  name: z.string().min(1, "Name is required"),
  email: z.string().email(),
  bio: z.string().optional(),
  twitter: z.string().optional(),
  avatar: z.string().optional(),
});

export default function AuthorList() {
  const { data: authors, isLoading } = useListAuthors();
  const createAuthor = useCreateAuthor();
  const updateAuthor = useUpdateAuthor();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const [open, setOpen] = useState(false);
  const [editingAuthor, setEditingAuthor] = useState<Author | null>(null);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: { name: "", email: "", bio: "", twitter: "", avatar: "" },
  });

  const handleOpenNew = () => {
    setEditingAuthor(null);
    form.reset({ name: "", email: "", bio: "", twitter: "", avatar: "" });
    setOpen(true);
  };

  const handleOpenEdit = (author: Author) => {
    setEditingAuthor(author);
    form.reset({
      name: author.name,
      email: author.email,
      bio: author.bio || "",
      twitter: author.twitter || "",
      avatar: author.avatar || ""
    });
    setOpen(true);
  };

  const onSubmit = (values: z.infer<typeof formSchema>) => {
    if (editingAuthor) {
      updateAuthor.mutate({ id: editingAuthor.id, data: values }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListAuthorsQueryKey() });
          toast({ title: "TX_CONFIRMED", description: "Identity updated." });
          setOpen(false);
        },
        onError: () => toast({ title: "TX_FAILED", variant: "destructive" })
      });
    } else {
      createAuthor.mutate({ data: values }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListAuthorsQueryKey() });
          toast({ title: "TX_CONFIRMED", description: "Identity registered." });
          setOpen(false);
        },
        onError: () => toast({ title: "TX_FAILED", variant: "destructive" })
      });
    }
  };

  const isPending = createAuthor.isPending || updateAuthor.isPending;

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-mono font-bold tracking-tight uppercase">Authors</h1>
          <Dialog open={open} onOpenChange={setOpen}>
            <Button onClick={handleOpenNew} className="rounded-none font-mono">
              <Plus className="mr-2 h-4 w-4" /> ADD_IDENTITY
            </Button>
            <DialogContent className="rounded-none border-border bg-card max-w-md">
              <DialogHeader>
                <DialogTitle className="font-mono uppercase">{editingAuthor ? "Update Identity" : "Register Identity"}</DialogTitle>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="font-mono">Name / Alias</FormLabel>
                        <FormControl><Input {...field} className="rounded-none font-mono" /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="font-mono">Email</FormLabel>
                        <FormControl><Input {...field} type="email" className="rounded-none font-mono" /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="twitter"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="font-mono">Twitter Handle</FormLabel>
                        <FormControl><Input {...field} className="rounded-none font-mono" /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="bio"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="font-mono">Bio</FormLabel>
                        <FormControl><Input {...field} className="rounded-none font-mono" /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="avatar"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="font-mono">Avatar URL</FormLabel>
                        <FormControl><Input {...field} className="rounded-none font-mono" /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <Button type="submit" disabled={isPending} className="w-full rounded-none font-mono">
                    {isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />} SUBMIT_TX
                  </Button>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>

        {isLoading ? (
          <div className="flex h-32 items-center justify-center">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : (
          <div className="border border-border bg-card">
            <Table>
              <TableHeader>
                <TableRow className="border-border hover:bg-transparent">
                  <TableHead className="font-mono w-[80px]">Avatar</TableHead>
                  <TableHead className="font-mono">Identity</TableHead>
                  <TableHead className="font-mono">Contact</TableHead>
                  <TableHead className="font-mono text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {authors?.map((author) => (
                  <TableRow key={author.id} className="border-border">
                    <TableCell>
                      <Avatar className="rounded-none border border-border h-10 w-10">
                        <AvatarImage src={author.avatar || `https://api.dicebear.com/7.x/identicon/svg?seed=${author.name}`} className="grayscale" />
                        <AvatarFallback className="rounded-none font-mono bg-accent text-accent-foreground">{author.name.substring(0, 2).toUpperCase()}</AvatarFallback>
                      </Avatar>
                    </TableCell>
                    <TableCell className="font-medium font-mono">
                      <div>{author.name}</div>
                      {author.twitter && <div className="text-xs text-muted-foreground">@{author.twitter}</div>}
                    </TableCell>
                    <TableCell className="font-mono text-muted-foreground text-sm">{author.email}</TableCell>
                    <TableCell className="text-right">
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="rounded-none hover:text-primary"
                        onClick={() => handleOpenEdit(author)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </div>
    </AdminLayout>
  );
}
