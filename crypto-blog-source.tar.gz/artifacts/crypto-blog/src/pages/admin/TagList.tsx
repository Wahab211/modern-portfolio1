import { AdminLayout } from "@/components/layout/AdminLayout";
import { useListTags, getListTagsQueryKey, useCreateTag } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Loader2, Plus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useState } from "react";
import { Badge } from "@/components/ui/badge";

const formSchema = z.object({
  name: z.string().min(1, "Name is required").regex(/^[a-zA-Z0-9-]+$/, "Only alphanumeric and dash characters allowed"),
});

export default function TagList() {
  const { data: tags, isLoading } = useListTags();
  const createTag = useCreateTag();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const [open, setOpen] = useState(false);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: { name: "" },
  });

  const onSubmit = (values: z.infer<typeof formSchema>) => {
    createTag.mutate({ data: values }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListTagsQueryKey() });
        toast({ title: "TX_CONFIRMED", description: "Tag deployed." });
        setOpen(false);
        form.reset();
      },
      onError: () => toast({ title: "TX_FAILED", variant: "destructive" })
    });
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-mono font-bold tracking-tight uppercase">Tags Index</h1>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button className="rounded-none font-mono">
                <Plus className="mr-2 h-4 w-4" /> DEPLOY_TAG
              </Button>
            </DialogTrigger>
            <DialogContent className="rounded-none border-border bg-card max-w-sm">
              <DialogHeader>
                <DialogTitle className="font-mono uppercase">Deploy New Tag</DialogTitle>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="font-mono">Tag Name</FormLabel>
                        <FormControl><Input {...field} className="rounded-none font-mono lowercase" placeholder="e.g. defi, layer-2" /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <Button type="submit" disabled={createTag.isPending} className="w-full rounded-none font-mono">
                    {createTag.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />} SUBMIT_TX
                  </Button>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>

        {isLoading ? (
          <div className="flex h-32 items-center justify-center">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : (
          <div className="border border-border bg-card">
            <Table>
              <TableHeader>
                <TableRow className="border-border hover:bg-transparent">
                  <TableHead className="font-mono">Tag</TableHead>
                  <TableHead className="font-mono">Slug</TableHead>
                  <TableHead className="font-mono text-right">Posts Count</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {tags?.map((tag) => (
                  <TableRow key={tag.id} className="border-border">
                    <TableCell>
                      <Badge variant="outline" className="rounded-none font-mono">
                        #{tag.name}
                      </Badge>
                    </TableCell>
                    <TableCell className="font-mono text-muted-foreground">{tag.slug}</TableCell>
                    <TableCell className="text-right font-mono">{tag.postCount || 0}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </div>
    </AdminLayout>
  );
}
