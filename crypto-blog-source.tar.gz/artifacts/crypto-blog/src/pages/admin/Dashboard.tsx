import { AdminLayout } from "@/components/layout/AdminLayout";
import { useGetStats, useHealthCheck } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { FileText, Tags, Users, Eye, Loader2, Activity } from "lucide-react";
import { format } from "date-fns";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

export default function Dashboard() {
  const { data: stats, isLoading } = useGetStats();
  const { data: health } = useHealthCheck();

  if (isLoading) {
    return (
      <AdminLayout>
        <div className="flex h-[50vh] items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </AdminLayout>
    );
  }

  if (!stats) return null;

  const statCards = [
    { title: "Total Posts", value: stats.totalPosts, icon: FileText },
    { title: "Total Views", value: stats.totalViews, icon: Eye },
    { title: "Categories", value: stats.totalCategories, icon: Tags },
    { title: "Authors", value: stats.totalAuthors, icon: Users },
  ];

  return (
    <AdminLayout>
      <div className="space-y-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <h1 className="text-3xl font-mono font-bold tracking-tight">TERMINAL_OVERVIEW</h1>
          <Badge variant="outline" className="font-mono bg-card w-fit">
            <Activity className="h-3 w-3 mr-2 text-primary" />
            NODE_STATUS: <span className={health?.status === "ok" ? "text-primary ml-1" : "text-destructive ml-1"}>{health?.status?.toUpperCase() || "UNKNOWN"}</span>
          </Badge>
        </div>
        
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {statCards.map((stat, idx) => (
            <Card key={idx} className="rounded-none border-border bg-card hover:border-primary/50 transition-colors">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-mono font-medium text-muted-foreground uppercase">
                  {stat.title}
                </CardTitle>
                <stat.icon className="h-4 w-4 text-primary" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-mono font-bold">{stat.value}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid gap-4 md:grid-cols-2">
          <Card className="rounded-none border-border bg-card">
            <CardHeader>
              <CardTitle className="font-mono text-lg uppercase">Post Status Distribution</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col gap-4">
                <div className="flex items-center justify-between border-b border-border/50 pb-2">
                  <span className="font-mono text-muted-foreground">PUBLISHED</span>
                  <span className="font-mono font-bold text-primary">{stats.publishedPosts}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="font-mono text-muted-foreground">DRAFT</span>
                  <span className="font-mono font-bold">{stats.draftPosts}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-4">
          <h2 className="text-xl font-mono font-bold uppercase border-b border-border pb-2">Recent Block Activity</h2>
          <div className="border border-border bg-card">
            <Table>
              <TableHeader>
                <TableRow className="border-border hover:bg-transparent">
                  <TableHead className="font-mono">Title</TableHead>
                  <TableHead className="font-mono">Status</TableHead>
                  <TableHead className="font-mono">Date</TableHead>
                  <TableHead className="font-mono text-right">Views</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {stats.recentPosts.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center font-mono text-muted-foreground py-8">
                      NO_ACTIVITY_FOUND
                    </TableCell>
                  </TableRow>
                ) : (
                  stats.recentPosts.map((post) => (
                    <TableRow key={post.id} className="border-border">
                      <TableCell className="font-medium font-mono">{post.title}</TableCell>
                      <TableCell>
                        <Badge variant={post.status === "published" ? "default" : "secondary"} className="rounded-none font-mono">
                          {post.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="font-mono text-muted-foreground">
                        {format(new Date(post.createdAt), "MMM d, yyyy")}
                      </TableCell>
                      <TableCell className="text-right font-mono">{post.views || 0}</TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}
