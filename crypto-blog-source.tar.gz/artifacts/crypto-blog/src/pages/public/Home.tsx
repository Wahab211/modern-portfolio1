import { PublicLayout } from "@/components/layout/PublicLayout";
import { PostCard } from "@/components/shared/PostCard";
import { useGetFeaturedPosts, useListPosts } from "@workspace/api-client-react";
import { motion } from "framer-motion";
import { staggerContainer, slideInLeft } from "@/lib/motion";
import { Loader2, ArrowRight } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function Home() {
  const { data: featuredPosts, isLoading: isLoadingFeatured } = useGetFeaturedPosts();
  const { data: recentPosts, isLoading: isLoadingRecent } = useListPosts({ limit: 6 });

  return (
    <PublicLayout>
      <div className="space-y-16 pb-16">
        {/* Hero Section */}
        <section className="relative overflow-hidden py-12 md:py-24 border-b border-border/40">
          <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)]" />
          <div className="relative">
            <motion.div 
              initial="hidden"
              animate="visible"
              variants={slideInLeft}
              className="max-w-3xl"
            >
              <h1 className="text-4xl font-mono font-black tracking-tighter sm:text-5xl md:text-6xl lg:text-7xl">
                DECODE THE <span className="text-primary block">BLOCKCHAIN</span>
              </h1>
              <p className="mt-6 text-lg text-muted-foreground font-mono max-w-xl">
                Alpha intelligence, deep-dives, and signal in a world of noise. Unfiltered perspectives from the edge of Web3.
              </p>
              <div className="mt-8 flex gap-4">
                <Button asChild size="lg" className="rounded-none font-mono font-bold">
                  <Link href="/blog">Read Latest</Link>
                </Button>
                <Button asChild variant="outline" size="lg" className="rounded-none font-mono">
                  <Link href="/admin">Enter Terminal</Link>
                </Button>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Featured Posts */}
        <section>
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-2xl font-mono font-bold flex items-center gap-2">
              <span className="h-3 w-3 bg-primary block animate-pulse" />
              TOP_SIGNAL
            </h2>
          </div>
          {isLoadingFeatured ? (
            <div className="flex justify-center p-12"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>
          ) : featuredPosts && featuredPosts.length > 0 ? (
            <motion.div 
              variants={staggerContainer}
              initial="hidden"
              animate="visible"
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
            >
              {featuredPosts.slice(0, 3).map((post, i) => (
                <PostCard key={post.id} post={post} isFeatured={i === 0 && featuredPosts.length === 1} />
              ))}
            </motion.div>
          ) : (
            <div className="text-muted-foreground font-mono">No featured content available.</div>
          )}
        </section>

        {/* Recent Posts Grid */}
        <section>
          <div className="flex items-center justify-between mb-8 border-b border-border/40 pb-4">
            <h2 className="text-2xl font-mono font-bold">LATEST_BLOCKS</h2>
            <Link href="/blog" className="text-primary font-mono text-sm flex items-center gap-1 hover:underline">
              VIEW_ALL <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
          
          {isLoadingRecent ? (
            <div className="flex justify-center p-12"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>
          ) : recentPosts && recentPosts.length > 0 ? (
            <motion.div 
              variants={staggerContainer}
              initial="hidden"
              animate="visible"
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
            >
              {recentPosts.map((post) => (
                <PostCard key={post.id} post={post} />
              ))}
            </motion.div>
          ) : (
            <div className="text-muted-foreground font-mono">System idle. No blocks mined yet.</div>
          )}
        </section>
      </div>
    </PublicLayout>
  );
}
