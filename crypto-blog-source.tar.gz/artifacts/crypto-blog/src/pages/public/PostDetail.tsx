import { PublicLayout } from "@/components/layout/PublicLayout";
import { useGetPost, useListPosts } from "@workspace/api-client-react";
import { useParams, Link } from "wouter";
import { format } from "date-fns";
import { Clock, ArrowLeft, Twitter } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function PostDetail() {
  const { id } = useParams();
  const { data: post, isLoading, error } = useGetPost(Number(id));
  
  // Get related posts (simplified by just getting latest)
  const { data: relatedPosts } = useListPosts({ limit: 3 });

  if (isLoading) {
    return (
      <PublicLayout>
        <div className="flex min-h-[50vh] items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </PublicLayout>
    );
  }

  if (error || !post) {
    return (
      <PublicLayout>
        <div className="flex flex-col min-h-[50vh] items-center justify-center text-center">
          <h1 className="text-4xl font-mono font-bold text-destructive">TX_NOT_FOUND</h1>
          <p className="mt-4 text-muted-foreground font-mono">The post you are looking for has been burned or does not exist.</p>
          <Button asChild variant="outline" className="mt-8 rounded-none font-mono">
            <Link href="/blog"><ArrowLeft className="mr-2 h-4 w-4"/> BACK_TO_FEED</Link>
          </Button>
        </div>
      </PublicLayout>
    );
  }

  return (
    <PublicLayout>
      <article className="max-w-4xl mx-auto py-8">
        <Button asChild variant="ghost" className="rounded-none font-mono mb-8 hover:bg-transparent hover:text-primary px-0">
          <Link href="/blog"><ArrowLeft className="mr-2 h-4 w-4"/> BACK</Link>
        </Button>

        <header className="mb-10 text-center md:text-left">
          <div className="flex flex-wrap items-center justify-center md:justify-start gap-4 mb-6">
            {post.category && (
              <Badge className="rounded-none bg-primary text-primary-foreground font-mono">
                {post.category.name}
              </Badge>
            )}
            <div className="flex items-center gap-2 text-sm font-mono text-muted-foreground">
              <time dateTime={post.createdAt}>
                {format(new Date(post.createdAt), "MMMM d, yyyy")}
              </time>
              <span>•</span>
              <span className="flex items-center gap-1">
                <Clock className="h-3 w-3" /> {post.readingTime || 5} MIN
              </span>
            </div>
          </div>
          
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-mono font-black tracking-tighter leading-tight uppercase">
            {post.title}
          </h1>
          
          <p className="mt-6 text-xl text-muted-foreground font-mono leading-relaxed border-l-2 border-primary pl-4 text-left">
            {post.excerpt}
          </p>
        </header>

        {post.coverImage && (
          <div className="my-12 relative aspect-[21/9] w-full border border-border">
            <img 
              src={post.coverImage} 
              alt={post.title}
              className="absolute inset-0 h-full w-full object-cover filter grayscale hover:grayscale-0 transition-all duration-700"
            />
          </div>
        )}

        <div className="prose prose-lg dark:prose-invert max-w-none font-sans text-foreground/90 prose-headings:font-mono prose-headings:uppercase prose-a:text-primary prose-a:no-underline hover:prose-a:underline prose-img:border prose-img:border-border">
          {/* Simple render of text content. A real app might use MDX */}
          {post.content.split('\n').map((paragraph, idx) => (
            paragraph ? <p key={idx}>{paragraph}</p> : <br key={idx} />
          ))}
        </div>

        <div className="mt-12 pt-8 border-t border-border flex flex-wrap gap-2">
          {post.tags?.map(tag => (
            <Badge key={tag.id} variant="secondary" className="rounded-none font-mono">
              #{tag.name}
            </Badge>
          ))}
        </div>

        <footer className="mt-16 bg-card border border-border p-8 flex flex-col sm:flex-row items-center sm:items-start gap-6">
          <img
            src={post.author?.avatar || `https://api.dicebear.com/7.x/identicon/svg?seed=${post.author?.name}&bg=000000`}
            alt={post.author?.name}
            className="h-24 w-24 object-cover border border-border grayscale"
          />
          <div className="flex-1 text-center sm:text-left">
            <h3 className="text-xl font-mono font-bold">{post.author?.name || "Anonymous"}</h3>
            <p className="text-muted-foreground mt-2">{post.author?.bio || "A cryptographic entity traversing the digital realm."}</p>
            {post.author?.twitter && (
              <a href={`https://twitter.com/${post.author.twitter}`} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 mt-4 text-primary hover:underline font-mono text-sm">
                <Twitter className="h-4 w-4" /> @{post.author.twitter}
              </a>
            )}
          </div>
        </footer>
      </article>
    </PublicLayout>
  );
}
