import { PublicLayout } from "@/components/layout/PublicLayout";
import { PostCard } from "@/components/shared/PostCard";
import { useListPosts, useListCategories } from "@workspace/api-client-react";
import { useState } from "react";
import { Search, Loader2, Filter } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";
import { staggerContainer } from "@/lib/motion";

export default function BlogList() {
  const [search, setSearch] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("");

  const { data: categories } = useListCategories();
  
  // Debounce search in a real app, simplified here
  const { data: posts, isLoading } = useListPosts({ 
    search: search.length > 2 ? search : undefined,
    category: selectedCategory || undefined
  });

  return (
    <PublicLayout>
      <div className="space-y-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6 border-b border-border pb-8">
          <div>
            <h1 className="text-4xl font-mono font-black tracking-tighter uppercase">Market Intel</h1>
            <p className="text-muted-foreground font-mono mt-2">Filter the noise. Find the alpha.</p>
          </div>
          
          <div className="w-full md:w-auto flex flex-col gap-4">
            <div className="relative w-full md:w-80">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input 
                type="search" 
                placeholder="SEARCH_QUERY..." 
                className="pl-9 rounded-none border-border bg-card font-mono focus-visible:ring-primary"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3 overflow-x-auto pb-2 scrollbar-hide">
          <Filter className="h-4 w-4 text-muted-foreground shrink-0" />
          <Badge 
            variant="outline"
            className={`rounded-none font-mono cursor-pointer transition-colors shrink-0 ${!selectedCategory ? 'bg-primary text-primary-foreground border-primary' : 'hover:border-primary'}`}
            onClick={() => setSelectedCategory("")}
          >
            ALL
          </Badge>
          {categories?.map((cat) => (
            <Badge 
              key={cat.id}
              variant="outline"
              className={`rounded-none font-mono cursor-pointer transition-colors shrink-0 ${selectedCategory === cat.slug ? 'bg-primary text-primary-foreground border-primary' : 'hover:border-primary'}`}
              onClick={() => setSelectedCategory(cat.slug)}
            >
              {cat.name.toUpperCase()}
            </Badge>
          ))}
        </div>

        {isLoading ? (
          <div className="flex justify-center p-24">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : posts && posts.length > 0 ? (
          <motion.div 
            variants={staggerContainer}
            initial="hidden"
            animate="visible"
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {posts.map((post) => (
              <PostCard key={post.id} post={post} />
            ))}
          </motion.div>
        ) : (
          <div className="border border-dashed border-border p-12 text-center bg-accent/10">
            <h3 className="font-mono text-lg font-bold">404_NO_ALPHA_FOUND</h3>
            <p className="text-muted-foreground font-mono mt-2">Adjust your search parameters.</p>
          </div>
        )}
      </div>
    </PublicLayout>
  );
}
