import { PublicLayout } from "@/components/layout/PublicLayout";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Terminal } from "lucide-react";

export default function NotFound() {
  return (
    <PublicLayout>
      <div className="flex min-h-[70vh] flex-col items-center justify-center text-center">
        <div className="rounded-full bg-accent/20 p-6 mb-6">
          <Terminal className="h-16 w-16 text-primary" />
        </div>
        <h1 className="text-6xl font-mono font-black tracking-tighter text-destructive">404</h1>
        <h2 className="mt-4 text-2xl font-mono font-bold uppercase tracking-widest">Connection Refused</h2>
        <p className="mt-4 max-w-md text-muted-foreground font-mono">
          The node you are trying to reach does not exist on this network. Please check your address or return to the genesis block.
        </p>
        <div className="mt-8">
          <Button asChild size="lg" className="rounded-none font-mono font-bold">
            <Link href="/">RETURN_TO_GENESIS</Link>
          </Button>
        </div>
      </div>
    </PublicLayout>
  );
}
