import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard,
  FileText,
  Tags,
  Users,
  Hexagon,
  LogOut,
  Hash
} from "lucide-react";

export function AdminSidebar() {
  const [location] = useLocation();

  const navItems = [
    { href: "/admin", icon: LayoutDashboard, label: "Dashboard" },
    { href: "/admin/posts", icon: FileText, label: "Posts" },
    { href: "/admin/categories", icon: Tags, label: "Categories" },
    { href: "/admin/tags", icon: Hash, label: "Tags" },
    { href: "/admin/authors", icon: Users, label: "Authors" },
  ];

  return (
    <aside className="fixed inset-y-0 left-0 z-10 w-64 flex-col border-r border-border bg-card hidden md:flex">
      <div className="flex h-16 items-center border-b border-border px-6">
        <Link href="/" className="flex items-center gap-2 text-foreground hover:text-primary transition-colors">
          <Hexagon className="h-6 w-6 text-primary" />
          <span className="font-mono font-bold tracking-tight uppercase">BlockFeed</span>
        </Link>
      </div>
      <div className="flex-1 overflow-auto py-6">
        <nav className="grid gap-2 px-4">
          {navItems.map((item) => {
            const isActive = location === item.href || (item.href !== "/admin" && location.startsWith(item.href));
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex items-center gap-3 rounded-none px-3 py-2 text-sm font-mono font-medium transition-all hover:text-primary hover:bg-accent/50",
                  isActive ? "bg-accent text-primary border-l-2 border-primary" : "text-muted-foreground border-l-2 border-transparent"
                )}
              >
                <item.icon className="h-4 w-4" />
                {item.label}
              </Link>
            );
          })}
        </nav>
      </div>
      <div className="border-t border-border p-4">
        <Link
          href="/"
          className="flex items-center gap-3 rounded-none px-3 py-2 text-sm font-mono font-medium text-muted-foreground transition-all hover:text-primary hover:bg-accent/50"
        >
          <LogOut className="h-4 w-4" />
          Exit Terminal
        </Link>
      </div>
    </aside>
  );
}
