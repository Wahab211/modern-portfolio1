import { ReactNode } from "react";
import { Navbar } from "./Navbar";

export function PublicLayout({ children }: { children: ReactNode }) {
  return (
    <div className="relative min-h-[100dvh] flex flex-col bg-background selection:bg-primary selection:text-primary-foreground">
      <Navbar />
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {children}
      </main>
      <footer className="border-t border-border/40 py-6 md:py-0">
        <div className="container mx-auto max-w-7xl flex flex-col items-center justify-between gap-4 md:h-16 md:flex-row px-4 sm:px-6 lg:px-8">
          <p className="text-sm font-mono text-muted-foreground">
            &copy; {new Date().getFullYear()} BlockFeed. Immutable ledger of thoughts.
          </p>
        </div>
      </footer>
    </div>
  );
}
