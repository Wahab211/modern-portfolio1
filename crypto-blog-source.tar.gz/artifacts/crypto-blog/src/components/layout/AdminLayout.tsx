import { ReactNode } from "react";
import { AdminSidebar } from "./AdminSidebar";
import { ThemeToggle } from "./ThemeToggle";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Menu, Hexagon, LayoutDashboard, FileText, Tags, Users, LogOut, Hash } from "lucide-react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";

export function AdminLayout({ children }: { children: ReactNode }) {
  const [location] = useLocation();

  const navItems = [
    { href: "/admin", icon: LayoutDashboard, label: "Dashboard" },
    { href: "/admin/posts", icon: FileText, label: "Posts" },
    { href: "/admin/categories", icon: Tags, label: "Categories" },
    { href: "/admin/tags", icon: Hash, label: "Tags" },
    { href: "/admin/authors", icon: Users, label: "Authors" },
  ];

  return (
    <div className="relative min-h-[100dvh] flex w-full bg-background selection:bg-primary selection:text-primary-foreground">
      <AdminSidebar />
      <div className="flex flex-1 flex-col md:pl-64">
        <header className="sticky top-0 z-30 flex h-16 items-center gap-4 border-b border-border bg-background px-4 sm:px-6">
          <Sheet>
            <SheetTrigger asChild>
              <Button size="icon" variant="outline" className="md:hidden border-border rounded-none">
                <Menu className="h-5 w-5" />
                <span className="sr-only">Toggle Menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-64 bg-card border-r-border p-0">
              <div className="flex h-16 items-center border-b border-border px-6">
                <Link href="/" className="flex items-center gap-2 text-foreground">
                  <Hexagon className="h-6 w-6 text-primary" />
                  <span className="font-mono font-bold tracking-tight uppercase">BlockFeed</span>
                </Link>
              </div>
              <div className="flex-1 overflow-auto py-6">
                <nav className="grid gap-2 px-4">
                  {navItems.map((item) => {
                    const isActive = location === item.href || (item.href !== "/admin" && location.startsWith(item.href));
                    return (
                      <Link
                        key={item.href}
                        href={item.href}
                        className={cn(
                          "flex items-center gap-3 rounded-none px-3 py-2 text-sm font-mono font-medium",
                          isActive ? "bg-accent text-primary border-l-2 border-primary" : "text-muted-foreground border-l-2 border-transparent"
                        )}
                      >
                        <item.icon className="h-4 w-4" />
                        {item.label}
                      </Link>
                    );
                  })}
                </nav>
              </div>
              <div className="border-t border-border p-4">
                <Link
                  href="/"
                  className="flex items-center gap-3 rounded-none px-3 py-2 text-sm font-mono font-medium text-muted-foreground"
                >
                  <LogOut className="h-4 w-4" />
                  Exit Terminal
                </Link>
              </div>
            </SheetContent>
          </Sheet>
          <div className="flex-1" />
          <ThemeToggle />
        </header>
        <main className="flex-1 p-4 sm:p-6 lg:p-8">
          {children}
        </main>
      </div>
    </div>
  );
}
