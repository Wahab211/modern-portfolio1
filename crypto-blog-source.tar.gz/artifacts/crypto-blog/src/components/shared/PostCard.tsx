import { Link } from "wouter";
import { format } from "date-fns";
import { Clock, TrendingUp } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Post } from "@workspace/api-client-react";
import { motion } from "framer-motion";
import { fadeIn } from "@/lib/motion";

export function PostCard({ post, isFeatured = false }: { post: Post; isFeatured?: boolean }) {
  return (
    <motion.article 
      variants={fadeIn}
      className={`group relative flex flex-col items-start justify-between border border-border bg-card hover:border-primary transition-all duration-300 ${
        isFeatured ? "col-span-full md:grid md:grid-cols-2 gap-8 p-6" : "p-5"
      }`}
    >
      <div className={`relative w-full overflow-hidden ${isFeatured ? "aspect-[16/9] md:aspect-auto h-full" : "aspect-video mb-5"}`}>
        {post.coverImage ? (
          <img
            src={post.coverImage}
            alt={post.title}
            className="absolute inset-0 h-full w-full object-cover transition-transform duration-500 group-hover:scale-105 filter grayscale hover:grayscale-0"
          />
        ) : (
          <div className="absolute inset-0 h-full w-full bg-accent/20 flex items-center justify-center font-mono text-muted-foreground">
            NO IMAGE
          </div>
        )}
        <div className="absolute top-3 left-3 flex gap-2">
          {post.category && (
            <Badge className="rounded-none bg-background/80 backdrop-blur border-border text-foreground hover:bg-primary hover:text-primary-foreground font-mono">
              {post.category.name}
            </Badge>
          )}
          {post.featured && (
            <Badge className="rounded-none bg-primary text-primary-foreground border-transparent font-mono flex items-center gap-1">
              <TrendingUp className="h-3 w-3" /> Featured
            </Badge>
          )}
        </div>
      </div>

      <div className={`flex flex-col flex-1 w-full ${isFeatured ? "justify-center" : ""}`}>
        <div className="flex items-center gap-x-4 text-xs font-mono text-muted-foreground mb-3">
          <time dateTime={post.createdAt}>
            {format(new Date(post.createdAt), "MMM d, yyyy")}
          </time>
          <div className="flex items-center gap-1">
            <Clock className="h-3 w-3" />
            {post.readingTime || 5} min read
          </div>
        </div>
        <div className="group relative">
          <h3 className="mt-3 text-xl font-mono font-bold leading-tight text-foreground group-hover:text-primary transition-colors">
            <Link href={`/blog/${post.id}`}>
              <span className="absolute inset-0" />
              {post.title}
            </Link>
          </h3>
          <p className="mt-4 line-clamp-3 text-sm leading-relaxed text-muted-foreground">
            {post.excerpt}
          </p>
        </div>
        <div className="relative mt-auto pt-6 flex items-center gap-x-4">
          <img
            src={post.author?.avatar || `https://api.dicebear.com/7.x/identicon/svg?seed=${post.author?.name}&bg=000000`}
            alt=""
            className="h-10 w-10 bg-accent grayscale group-hover:grayscale-0 transition-all border border-border"
          />
          <div className="text-sm leading-6">
            <p className="font-semibold text-foreground font-mono">
              <span className="absolute inset-0" />
              {post.author?.name || "Anonymous"}
            </p>
            <p className="text-muted-foreground text-xs font-mono">{post.author?.twitter || "Writer"}</p>
          </div>
        </div>
      </div>
    </motion.article>
  );
}
