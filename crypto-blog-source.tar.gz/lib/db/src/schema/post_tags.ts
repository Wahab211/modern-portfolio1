import { pgTable, integer, primaryKey } from "drizzle-orm/pg-core";
import { postsTable } from "./posts";
import { tagsTable } from "./tags";

export const postTagsTable = pgTable("post_tags", {
  postId: integer("post_id").notNull().references(() => postsTable.id, { onDelete: "cascade" }),
  tagId: integer("tag_id").notNull().references(() => tagsTable.id, { onDelete: "cascade" }),
}, (t) => [primaryKey({ columns: [t.postId, t.tagId] })]);

export type PostTag = typeof postTagsTable.$inferSelect;
